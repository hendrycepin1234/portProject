
function formValidate()
{
    const validName = checkName();
    const validEmail = checkEmail();
    const validSubject = checkSubject();
    const validMessage = checkMessage();

    if(validName && validEmail && validSubject && validMessage){
        return true;
    }
    else{
        return false;
    }
}

function checkName(){
    const testName = document.getElementById("name").value;
    const nameError = document.getElementById("formName");

    if(testName === '' || testName.length < 3){
        nameError.removeAttribute("hidden");
        return false;
    }
    else{
        nameError.setAttribute("hidden", "");
    }

    return true;
}

function checkEmail(){
    const testemail = document.getElementById("email").value;
    const emailError = document.getElementById("formEmail");

   if(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(testemail)){
        emailError.setAttribute("hidden", "");
        return true;
    }
    else{
        emailError.removeAttribute("hidden");
        return false;
    }
}

function checkSubject(){
    const testSubject = document.getElementById("subject").value;
    const subjectError = document.getElementById("formSubject");

    if(testSubject === ''){
        subjectError.removeAttribute("hidden");
        return false;
    }
    else{
        subjectError.setAttribute("hidden", "");
    }

    return true;
}

function checkMessage(){
    const testMessage = document.getElementById("message").value;
    const messageError = document.getElementById("formMessage");

    if(testMessage === '' || testMessage.length < 20){
        messageError.removeAttribute("hidden");
        return false;
    }
    else{
        messageError.setAttribute("hidden", "");
    }

    return true;
}

/*Clock*/


function updateTime(){

const newdate = new Date()
const time = document.getElementById("DateTime");
time.textContent = newdate.toLocaleString();

}
setInterval(updateTime,1000);



/* project cards*/

const cards = document.querySelectorAll(".projectCard"); 

cards.forEach(function(card){

   card.addEventListener('mouseenter',mouseChange)
    card.addEventListener('mouseleave', mouseReturn)

});


function mouseChange(){
this.style.borderColor ="Green";
this.style.transform = "scale(1.02)";
}

function mouseReturn(){
this.style.borderColor ="";
this.style.transform = "scale(1)";
}


/*back to top*/

const scrollButton = document.getElementById("scrollButton");

window.addEventListener("scroll",checkScroll);

function checkScroll(){

    if(window.scrollY > 200)
    {
        scrollButton.removeAttribute("hidden");
    }
    else
    {
        scrollButton.setAttribute("hidden", "");
    }
}


scrollButton.addEventListener("click",scrollUp)

function scrollUp(){
    window.scrollTo({
        top: 0, behavior: "smooth"

    });
}


/*image gallery*/

const   galleryPhoto = document.getElementById("galleryPhoto");

const  gallery = [ "gameplay1.png", "gameplay2.png", "koopa.png", "fly.png", "sidestepper.png", "fireball.png" ];

let currentImage = 0;

function changeImage(){

    currentImage++;

    if(currentImage >= gallery.length)
    {
        currentImage = 0;

    }

    galleryPhoto.src = gallery[currentImage];
}
 setInterval(changeImage, 5000);

